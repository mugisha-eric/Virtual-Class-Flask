from flask import Flask, render_template, redirect, request, url_for, session
import sqlite3 as sq

app = Flask(__name__)
app.secret_key = 'super secret key'

conn = sq.connect('CREDENTIAL.db')
cur = conn.cursor()
cur.execute('''CREATE TABLE IF NOT EXISTS CREDENT (id INTEGER PRIMARY KEY AUTOINCREMENT, role TEXT, email TEXT, password TEXT, FName TEXT, LName TEXT, Gender TEXT)''')


@app.route('/')
def index():
    if 'role' in session:
        if session['role'] == 'Teacher':
            return redirect(url_for('dashboard', role = 'Teacher'))
        else:
            return redirect(url_for('dashboard', role = 'Student'))
       
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'role' in session:
        if session['role'] == 'Teacher':
            return redirect(url_for('dashboard', role = 'Teacher'))
        else:
            return redirect(url_for('dashboard', role = 'Student'))
       
        
    conn = sq.connect('CREDENTIAL.db')
    cur = conn.cursor()

    if request.method == 'POST':
        role = request.form['role']
        email = request.form['email']
        password = request.form['password']

        user = cur.execute("SELECT * FROM CREDENT WHERE role=? AND email = ? AND password=?", (role, email, password)).fetchone()
        
        cur.close()
        conn.close()
        if user != None:
            session['email'] = email
            session['fname'] = user[4]
            session['lname'] = user[5]

            if role == 'Teacher':
                session['role'] = 'Teacher'

                return redirect(url_for('dashboard', role='Teacher'))
            
            else:
                session['role'] = 'Student'
                return redirect(url_for('dashboard', role='Student'))
        else:        
            return render_template('login.html', error="email or password is incorrect!")

    return render_template('login.html')

@app.route('/register', methods=['POST', 'GET'])
def register():
    if 'role' in session:
        if session['role'] == 'Teacher':
            return redirect(url_for('dashboard', role = 'Teacher'))
        else:
            return redirect(url_for('dashboard', role = 'Student'))
       

    conn = sq.connect('CREDENTIAL.db')
    cur = conn.cursor()

    if request.method == 'POST':

        role = request.form['role']
        email = request.form['email']
        password = request.form['password']
        fname = request.form['FName']
        lname = request.form['LName']
        gender = request.form['gender']

        query = "SELECT * FROM CREDENT WHERE role = ? AND email = ?"
        exist = cur.execute(query, (role, email)).fetchone()
        

        if exist == None:
            cur.execute("INSERT INTO CREDENT (role, email, password, FName, LName, Gender) VALUES (?,?,?,?,?,?)", (role,email,password, fname, lname, gender))
            # Commit the changes
            conn.commit()
            return redirect(url_for('login'))

        else:
            return render_template('register.html', error='Error: User already exist! try to login or use different!')

    return render_template('register.html')

@app.route('/logout')
def logout():
    session.pop('role', None)
    session.pop('email', None)
    session.pop('fname', None)
    session.pop('lname', None)
    return redirect(url_for('login'))


@app.route('/dashboard/<role>')
def dashboard(role):
    if 'role' not in session:
            return redirect(url_for('login'))
    
    fnm = session['fname']
    lnm = session['lname']

    if role != session['role']:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    if role == 'Teacher':

        return render_template('Teacher/dashboard-teacher.html', FName=fnm, LName=lnm)
    elif role == 'Student':

        return render_template('Student/dashboard-student.html', FName=fnm, LName=lnm)
    else:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'

@app.route('/profile/<role>')
def prof(role):
    if 'role' not in session:
            return redirect(url_for('login'))
    

    if role != session['role']:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    
    if role == 'Teacher':
        return render_template('Teacher/profile-teacher.html', FName=session['fname'], LName=session['lname'], )
    elif role == 'Student':
        return render_template('Student/profile-student.html', FName=session['fname'], LName=session['lname'])
    else:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    
@app.route('/setting/<role>')
def setting(role):
    if 'role' not in session:
            return redirect(url_for('login'))
    

    if role != session['role']:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    
    if role == 'Teacher':
        return render_template('Teacher/setting-teacher.html', FName=session['fname'], LName=session['lname'])
    elif role == 'Student':
        return render_template('Student/setting-student.html', FName=session['fname'], LName=session['lname'])
    else:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    
@app.route('/discussions/<role>')
def discussions(role):
    if 'role' not in session:
            return redirect(url_for('login'))
    

    if role != session['role']:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    
    if role == 'Teacher':
        return render_template('Teacher/discussions-teacher.html', FName=session['fname'], LName=session['lname'])
    elif role == 'Student':
        return render_template('Student/discussions-student.html', FName=session['fname'], LName=session['lname'])
    else:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    

@app.route('/calendar/<role>')
def calendar(role):
    if 'role' not in session:
            return redirect(url_for('login'))
    

    if role != session['role']:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    
    if role == 'Teacher':
        return render_template('Teacher/calendar-teacher.html', FName=session['fname'], LName=session['lname'])
    elif role == 'Student':
        return render_template('Student/calendar-student.html', FName=session['fname'], LName=session['lname'])
    else:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    
@app.route('/Class/<action>/<role>')
def Class(action, role):
    if 'role' not in session:
            return redirect(url_for('login'))
    
    
    if role != session['role']:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    if action == 'create class' and role == 'Teacher':
        return render_template('Teacher/create-class.html', FName=session['fname'], LName=session['lname'])
    
    elif action == 'join class' and role == 'Student':
        return render_template('Student/join-class.html', FName=session['fname'], LName=session['lname'])
    
    if action == 'class work' and role == 'Teacher':
        return render_template('Teacher/class-work.html', FName=session['fname'], LName=session['lname'])
    
    elif action == 'class work' and role == 'Student':
        return render_template('Student/class-work.html', FName=session['fname'], LName=session['lname'])
    

    elif action == 'assign work' and role == 'Teacher':
        return render_template('Teacher/assign-work.html', FName=session['fname'], LName=session['lname'])
    
    elif action == 'archived class' and role == 'Teacher':
        return render_template('Teacher/archived-class-teacher.html', FName=session['fname'], LName=session['lname'])
    
    elif action == 'archived class' and role == 'Student':
        return render_template('Student/archived-class-student.html', FName=session['fname'], LName=session['lname'])
    
    else:
        return '<h3>No data found, Please Try <a href="../logout">login Again</a></h3>'
    
@app.route('/forgot password')
def forgot_pass():
    return render_template('forgot-password.html')

@app.route('/reset password')
def reset_pass():
    return render_template('reset-password.html')






























# Define a custom error handler for 400 errors
@app.errorhandler(400)
def page_not_found(error):
    return render_template('400.html'), 400

# Define a custom error handler for 403 errors
@app.errorhandler(403)
def page_not_found(error):
    return render_template('403.html'), 403

# Define a custom error handler for 404 errors
@app.errorhandler(404)
def page_not_found(error):
    return render_template('404.html'), 404

# Define a custom error handler for 500 errors
@app.errorhandler(500)
def page_not_found(error):
    return render_template('500.html'), 500

# Define a custom error handler for 503 errors
@app.errorhandler(503)
def page_not_found(error):
    return render_template('503.html'), 503

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=50, debug=True)
